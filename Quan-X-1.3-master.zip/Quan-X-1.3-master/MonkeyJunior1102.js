var obj = JSON.parse($response.body);

obj= {
{
	"status": "success",
	"message": "success",
	"code": 200,
	"data": {
		"country_code": "vi-VN",
		"is_vn": true,
		"purchased": {
			"pay_inapp": true,
			"time_expire": 1974896723,
			"product_list": [],
			"is_active": true,
			"is_free": false
		},
		"is_show_ads_app": [40, 50, 51],
		"current_time": 1574012803,
		"show_pay": false,
		"userInfo": {
			"email": "",
			"phone": "0984620985",
			"name": "",
			"address": "",
			"time_updated": 1574012795,
			"config_item": "http:\/\/www.api.monkeyuni.net\/data_app\/user_info\/json_config_item_1039489_2.zip",
			"users_id": 1039489,
			"max_profile": 3
		},
		"notify": [{
			"id": 106,
			"title": "MONKEY STORIES VINH D\u1ef0 \u0110\u1ea0T TOP 1 CH\u01af\u01a0NG TR\u00ccNH GI\u00c1O D\u1ee4C \u0110\u01af\u1ee2C T\u1ea2I V\u1ec0 NHI\u1ec0U NH\u1ea4T T\u1ea0I VI\u1ec6T NAM",
			"message": "Sau r\u1ea5t nhi\u1ec1u n\u1ed7 l\u1ef1c t\u1eeb \u0111\u1ed9i ng\u0169 ph\u00e1t tri\u1ec3n s\u1ea3n ph\u1ea9m v\u00e0 s\u1ef1 gi\u00fap s\u1ee9c h\u1ebft m\u00ecnh c\u1ee7a c\u00e1c b\u1ed1 m\u1eb9, ch\u01b0\u01a1ng tr\u00ecnh h\u1ecdc Monkey Stories \u0111\u00e3 ch\u00ednh th\u1ee9c \u0111\u1ea1t TOP 1 ch\u01b0\u01a1ng tr\u00ecnh gi\u00e1o d\u1ee5c \u0111\u01b0\u1ee3c t\u1ea3i v\u1ec1 nhi\u1ec1u nh\u1ea5t t\u1ea1i Vi\u1ec7t Nam.\r\nNh\u00e2n s\u1ef1 ki\u1ec7n \u0111\u1eb7c bi\u1ec7t n\u00e0y, Monkey Junior mu\u1ed1n m\u1eddi b\u1ed1 m\u1eb9 c\u00f9ng l\u1eafng nghe nh\u1eefng chia s\u1ebb c\u1ee7a c\u00e1c b\u1ed1 m\u1eb9 \u0111ang cho con s\u1eed d\u1ee5ng ch\u01b0\u01a1ng tr\u00ecnh h\u1ecdc Monkey Stories t\u1ea1i \u0111\u00e2y.",
			"url": "http:\/\/bit.ly\/Video-Trian",
			"created": 1528947895
		}, {
			"id": 80,
			"title": "B\u1ea3n \"si\u00eau c\u1eadp nh\u1eadt\" ch\u00e0o h\u00e8 2018",
			"message": "Monkey Junior Summer Update \u0111\u00e3 ch\u00ednh th\u1ee9c \u0111\u01b0\u1ee3c ra m\u1eaft t\u1ea5t c\u1ea3 ba m\u1eb9. Chi ti\u1ebft b\u1ea3n c\u1eadp nh\u1eadt bao g\u1ed3m:\r\n- Ra m\u1eaft ng\u00f4n ng\u1eef Nga\r\n- Th\u00eam m\u1edbi h\u01a1n 1500 b\u00e0i h\u1ecdc cho 4 ng\u00f4n ng\u1eef ti\u1ebfng Vi\u1ec7t, ti\u1ebfng Trung, ti\u1ebfng Ph\u00e1p v\u00e0 ti\u1ebfng T\u00e2y Ban Nha\r\n- Th\u00eam m\u1edbi 10 ho\u1ea1t \u0111\u1ed9ng t\u01b0\u01a1ng t\u00e1c b\u1ed5 tr\u1ee3 cho vi\u1ec7c d\u1ea1y h\u1ecdc\r\n- L\u01b0u gi\u1eef l\u1ea1i sticker ngay c\u1ea3 khi b\u1ecb x\u00f3a m\u1ea5t \u1ee9ng d\u1ee5ng.\r\nBa m\u1eb9 c\u00f9ng nhanh tay c\u1eadp nh\u1eadt \u1ee9ng d\u1ee5ng nh\u00e9!",
			"url": "",
			"created": 1527045225
		}],
		"update": {
			"id": 80,
			"status": "ignore",
			"url": "",
			"title": "B\u1ea3n \"si\u00eau c\u1eadp nh\u1eadt\" ch\u00e0o h\u00e8 2018",
			"message": "Monkey Junior Summer Update \u0111\u00e3 ch\u00ednh th\u1ee9c \u0111\u01b0\u1ee3c ra m\u1eaft t\u1ea5t c\u1ea3 ba m\u1eb9. Chi ti\u1ebft b\u1ea3n c\u1eadp nh\u1eadt bao g\u1ed3m:\r\n- Ra m\u1eaft ng\u00f4n ng\u1eef Nga\r\n- Th\u00eam m\u1edbi h\u01a1n 1500 b\u00e0i h\u1ecdc cho 4 ng\u00f4n ng\u1eef ti\u1ebfng Vi\u1ec7t, ti\u1ebfng Trung, ti\u1ebfng Ph\u00e1p v\u00e0 ti\u1ebfng T\u00e2y Ban Nha\r\n- Th\u00eam m\u1edbi 10 ho\u1ea1t \u0111\u1ed9ng t\u01b0\u01a1ng t\u00e1c b\u1ed5 tr\u1ee3 cho vi\u1ec7c d\u1ea1y h\u1ecdc\r\n- L\u01b0u gi\u1eef l\u1ea1i sticker ngay c\u1ea3 khi b\u1ecb x\u00f3a m\u1ea5t \u1ee9ng d\u1ee5ng.\r\nBa m\u1eb9 c\u00f9ng nhanh tay c\u1eadp nh\u1eadt \u1ee9ng d\u1ee5ng nh\u00e9!",
			"version_update": "23.3.0",
			"version_required": "0",
			"time_remind": 3
		},
		"limit_seconds_offline": 2599999200,
		"is_submit": false
	}
}
	
};

$done({body: JSON.stringify(obj)});

// Descriptions
